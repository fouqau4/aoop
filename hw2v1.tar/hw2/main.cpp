#include "mytar.h"
using namespace std;
int main( int argc, char* argv[] )
{
	list_content( argv[1] );
	return 0;
}
