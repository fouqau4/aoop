#ifndef _SW_MY_TAR_
#define _SW_MY_TAR_

#include "tarheader.h"

extern void list_content( const char* filename );



#endif
